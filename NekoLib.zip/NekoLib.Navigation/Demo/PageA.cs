﻿using PageNav.Metadata;
using PageNav.WinForms;
using PageNav.WinForms.UIElements;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo
{
    [PageBehavior(
    kind: PageKind.Default,
    cachePolicy: PageCachePolicy.StrongSingleton)]
    public partial class PageA : PageBase
    {
        public PageA()
        {
            InitializeComponent();
        }
    }
}
