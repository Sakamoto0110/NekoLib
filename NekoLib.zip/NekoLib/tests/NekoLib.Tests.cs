﻿namespace NekoLib.tests;
internal class NekoLib
{
}
