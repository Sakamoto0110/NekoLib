﻿namespace NekoLib.Diagnostics;

public class Telemetry
{

}
