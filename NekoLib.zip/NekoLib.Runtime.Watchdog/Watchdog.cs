﻿namespace NekoLib.Runtime.Watchdog;
internal class Watchdog
{
}
